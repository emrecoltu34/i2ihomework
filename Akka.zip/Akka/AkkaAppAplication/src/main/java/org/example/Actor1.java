package org.example;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;

public class Actor1 extends AbstractActor {
    private final ActorRef actor2;

    public Actor1(ActorRef actor2) {
        this.actor2 = actor2;
    }

    public static Props props(ActorRef actor2) {
        return Props.create(Actor1.class, () -> new Actor1(actor2));
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(String.class, msg -> {
                    System.out.println("Actor1 received message: " + msg);
                    // Actor1 mesaj gönderiyor
                    actor2.tell("Hi from Actor1", getSelf());
                })
                .matchEquals("Hi from Actor2", msg -> {
                    System.out.println("Actor1 received reply: " + msg);
                    // Aktör sistemi kapatılıyor
                    getContext().getSystem().terminate();
                })
                .build();
    }
}
