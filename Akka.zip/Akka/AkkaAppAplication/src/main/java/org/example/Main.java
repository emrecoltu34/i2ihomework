package org.example;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;

public class Main {
    public static void main(String[] args) {
        final ActorSystem system = ActorSystem.create("ActorSystem");

        // Actor2'yi oluşturun
        final ActorRef actor2 = system.actorOf(Actor2.props(null), "actor2");

        // Actor1'i oluşturun (Actor2 referansı ile)
        final ActorRef actor1 = system.actorOf(Actor1.props(actor2), "actor1");

        // Actor1'e mesaj gönder
        actor1.tell("Hi from Actor2", ActorRef.noSender());
    }
}
