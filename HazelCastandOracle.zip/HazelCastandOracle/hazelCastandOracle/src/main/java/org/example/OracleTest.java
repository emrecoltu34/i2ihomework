package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

public class OracleTest {

    public static void main(String[] args) {
          String userName="root";
          String password="1234";
         String dbUrl="jdbc:mysql://localhost:3306/world";



        try (Connection connection = DriverManager.getConnection(dbUrl, userName, password)) {
            // Tabloyu oluşturma
            dropTableIfExists(connection);
            createTable(connection);

            // 20.000 rastgele sayıyı ekleme ve zamanı ölçme
            truncateTable(connection);
            long timeTakenInsert20000 = insertRandomNumbers(connection, 20000);
            System.out.println("Inserting 20000 random numbers took for Oracle " + timeTakenInsert20000 + " milliseconds.");

            // 20.000 rastgele sayıyı seçme ve zamanı ölçme
            long timeTakenSelect20000 = selectRandomNumbers(connection, 20000);
            System.out.println("Selecting 20000 random numbers took for Oracle " + timeTakenSelect20000 + " milliseconds.");

            // 100.000 rastgele sayıyı ekleme ve zamanı ölçme
            truncateTable(connection);
            long timeTakenInsert100000 = insertRandomNumbers(connection, 100000);
            System.out.println("Inserting 100000 random numbers took for Oracle  " + timeTakenInsert100000 + " milliseconds.");

            // 100.000 rastgele sayıyı seçme ve zamanı ölçme
            long timeTakenSelect100000 = selectRandomNumbers(connection, 100000);
            System.out.println("Selecting 100000 random numbers took for Oracle " + timeTakenSelect100000 + " milliseconds.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void dropTableIfExists(Connection connection) throws SQLException {
        String dropTableSQL = "DROP TABLE IF EXISTS random_numbers";
        try (PreparedStatement preparedStatement = connection.prepareStatement(dropTableSQL)) {
            preparedStatement.executeUpdate();
        }
    }

    private static void createTable(Connection connection) throws SQLException {
        String createTableSQL = "CREATE TABLE random_numbers (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "value INT)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(createTableSQL)) {
            preparedStatement.executeUpdate();
        }
    }

    private static void truncateTable(Connection connection) throws SQLException {
        String truncateTableSQL = "TRUNCATE TABLE random_numbers";
        try (PreparedStatement preparedStatement = connection.prepareStatement(truncateTableSQL)) {
            preparedStatement.executeUpdate();
        }
    }

    private static long insertRandomNumbers(Connection connection, int count) throws SQLException {
        String insertSQL = "INSERT INTO random_numbers (value) VALUES (?)";
        Random random = new Random();
        long startTime = System.currentTimeMillis();

        try (PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {
            for (int i = 1; i <= count; i++) {
                preparedStatement.setInt(1, random.nextInt(1000000));
                preparedStatement.addBatch();
            }
            preparedStatement.executeBatch();
        }

        long endTime = System.currentTimeMillis();
        return endTime - startTime;
    }

    private static long selectRandomNumbers(Connection connection, int count) throws SQLException {
        String selectSQL = "SELECT value FROM random_numbers WHERE id = ?";
        Random random = new Random();
        long startTime = System.currentTimeMillis();

        try (PreparedStatement preparedStatement = connection.prepareStatement(selectSQL)) {
            for (int i = 1; i <= count; i++) {
                int randomId = random.nextInt(count) + 1;
                preparedStatement.setInt(1, randomId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        int value = resultSet.getInt("value");
                    }
                }
            }
        }

        long endTime = System.currentTimeMillis();
        return endTime - startTime;
    }
}