package org.example;

import com.hazelcast.config.Config;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;

import java.util.Random;

public class hazelCast {
    public static void main(String[] args) {
        // Create a Hazelcast instance
        Config config = new Config();
        HazelcastInstance hazelcastInstance = Hazelcast.newHazelcastInstance(config);

        // Get a distributed map
        IMap<Integer, Integer> map = hazelcastInstance.getMap("randomNumbers");

        try {
            // Insert 20,000 random numbers and measure time
            map.clear(); // Clear the map to ensure fresh start
            long timeTakenInsert20000 = insertRandomNumbers(map, 20000);
            System.out.println("Inserting 20000 random numbers took for HazelCast " + timeTakenInsert20000 + " milliseconds.");

            // Retrieve 20,000 random numbers and measure time
            long timeTakenSelect20000 = selectRandomNumbers(map, 20000);
            System.out.println("Selecting 20000 random numbers took HazelCast " + timeTakenSelect20000 + " milliseconds.");

            // Insert 100,000 random numbers and measure time
            map.clear(); // Clear the map again
            long timeTakenInsert100000 = insertRandomNumbers(map, 100000);
            System.out.println("Inserting 100000 random numbers took HazelCast " + timeTakenInsert100000 + " milliseconds.");

            // Retrieve 100,000 random numbers and measure time
            long timeTakenSelect100000 = selectRandomNumbers(map, 100000);
            System.out.println("Selecting 100000 random numbers took HazelCast " + timeTakenSelect100000 + " milliseconds.");
        } finally {
            // Shutdown Hazelcast instance
            hazelcastInstance.shutdown();
        }
    }

    private static long insertRandomNumbers(IMap<Integer, Integer> map, int count) {
        Random random = new Random();
        long startTime = System.currentTimeMillis();

        for (int i = 0; i < count; i++) {
            int key = i; // Use the index as the key
            int value = random.nextInt(1000000);
            map.put(key, value);
        }

        long endTime = System.currentTimeMillis();
        return endTime - startTime;
    }

    private static long selectRandomNumbers(IMap<Integer, Integer> map, int count) {
        Random random = new Random();
        long startTime = System.currentTimeMillis();

        for (int i = 0; i < count; i++) {
            int key = random.nextInt(count); // Random key for retrieval
            map.get(key);
        }

        long endTime = System.currentTimeMillis();
        return endTime - startTime;
    }
}