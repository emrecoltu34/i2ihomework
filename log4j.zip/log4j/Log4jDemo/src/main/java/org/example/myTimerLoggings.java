    package org.example;

    import org.apache.logging.log4j.LogManager;
    import org.apache.logging.log4j.Logger;

    import java.text.SimpleDateFormat;
    import java.util.Date;
    import java.util.Timer;
    import java.util.TimerTask;

    public class myTimerLoggings {

        private static final Logger logger = LogManager.getLogger(myTimerLoggings.class);

        public static void main(String[] args) {
            Timer timer = new Timer();

            // Debug log: seconds increment
            timer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
                    logger.debug(sdf.format(new Date()));
                }
            }, 0, 1000); // 1 second interval

            // Info log: minutes increment
            timer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:00");
                    logger.info(sdf.format(new Date()));
                }
            }, 0, 60000); // 1 minute interval

            // Error log: hours increment
            timer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:00:00");
                    logger.error(sdf.format(new Date()));
                }
            }, 0, 3600000); // 1 hour interval
        }
    }